# Content Research and Sourcing — Bean & Batch Roastery

## 1. Purpose
This document summarises the research conducted for each page of the Bean &
Batch Roastery website and lists where content and assets should be sourced
from before final submission.

## 2. Content by page

### Home (index.html)
- Value proposition and three brand pillars (traceable sourcing, small-batch
  roasting, unhurried café experience) — original content, written to reflect
  a specialty coffee positioning.
- Opening hours — original/placeholder; replace with real hours if using a
  real business.

### About Us (about.html)
- Founding story, mission, and sourcing approach — original content.
- Team roles (Head Roaster, Café Manager, Sourcing & Wholesale Lead) —
  original content; replace with real names/photos if applicable.

### Menu & Beans (products.html)
- Coffee origins, process, and tasting notes — written in the style of real
  specialty roasters; verify or replace with actual product data.
- Café menu and pricing — placeholder pricing in ZAR; update with real prices.

### Enquiry (enquiry.html)
- Form fields designed around three real enquiry types a coffee business
  receives: product, wholesale, and catering.

### Contact (contact.html)
- Two placeholder locations with embedded Google Maps (Rosebank and
  Melville, Johannesburg, used as illustrative addresses).
- Replace addresses, phone numbers, and map embeds with the real business's
  details before going live.

## 3. Sources to use for real assets
- **Photography/imagery:** Unsplash (unsplash.com) and Pexels (pexels.com) —
  both offer free, royalty-free images under permissive licences; search
  "coffee roastery", "latte art", "specialty coffee beans".
- **Icons:** Font Awesome (fontawesome.com) or Heroicons (heroicons.com),
  free tiers.
- **Fonts:** Google Fonts — Fraunces (display) and Inter (body), both open
  licence, loaded via `<link>` in each HTML file.
- **Social media:** Reference the organisation's own Instagram/Facebook
  posts for tone, product names, and real testimonials once a real
  organisation is confirmed with the lecturer.

## 4. Notes for final submission
- Swap all placeholder images, prices, addresses, and team details for the
  approved organisation's real information once the proposal is signed off.
- Keep a record of every external asset's source and licence for the
  README.md references section.
